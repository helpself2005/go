+++
title = "Hello World"
description = "Hello world example for Echo"
[menu.main]
  name = "Hello World"
  parent = "cookbook"
  weight = 1
+++

## Server

`server.go`

{{< embed "hello-world/server.go" >}}

## [Source Code]({{< source "hello-world" >}})

## Maintainers

- [vishr](https://github.com/vishr)
