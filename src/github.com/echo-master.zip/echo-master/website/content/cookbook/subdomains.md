+++
title = "Subdomains"
description = "Subdomains example for Echo"
[menu.main]
  name = "Subdomains"
  parent = "cookbook"
  weight = 10
+++

`server.go`

{{< embed "subdomains/server.go" >}}

## [Source Code]({{< source "subdomains" >}})

## Maintainers

- [axdg](https://github.com/axdg)
- [vishr](https://github.com/vishr)
