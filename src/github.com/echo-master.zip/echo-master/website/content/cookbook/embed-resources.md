+++
title = "Embed Resources"
description = "Embed resources example for Echo"
[menu.main]
  name = "Embed Resources"
  parent = "cookbook"
  weight = 14
+++

## With go.rice

`server.go`

{{< embed "embed-resources/server.go" >}}

## [Source Code]({{< source "embed-resources" >}})

## Maintainers

- [caarlos0](https://github.com/caarlos0)
- [maddie](https://github.com/maddie)
