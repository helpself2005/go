+++
title = "Cookbook"
description = "Echo cookbook"
type = "cookbook"
[menu.main]
  name = "Cookbook"
  pre = "<i class='fa fa-code'></i>"
  weight = 2
  identifier = "cookbook"
  url = "/cookbook"
+++

<script>location = '/cookbook/hello-world';</script>
